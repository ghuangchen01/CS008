//
// Created by Guanhao Huang Chen on 1/19/23.
//

#ifndef UCS8_SPRING23_REVIEW_STUBS_AND_DRIVERS_OPENING_H
#define UCS8_SPRING23_REVIEW_STUBS_AND_DRIVERS_OPENING_H

#include "Hangman.h"
class Opening {
public:
    void menu();
    void numOfPlayers(const int& player);
};


#endif //UCS8_SPRING23_REVIEW_STUBS_AND_DRIVERS_OPENING_H
