#include <iostream>
#include "Hangman.h"
#include "Tests.h"
int main()
{
    //wordBankDriver();
    //testWord();

    //VisualTestDriver
    //testBoard();

    testGame();
    return 0;
}
