//
// Created by Dave R. Smith on 1/10/23.
//

#ifndef UCS8_SPRING23_REVIEW_STUBS_AND_DRIVERS_USERINPUT_H
#define UCS8_SPRING23_REVIEW_STUBS_AND_DRIVERS_USERINPUT_H
#include <iostream>

class UserInput
{
public:
    UserInput();
    void getInput(char &letter);
    char getInput();

};


#endif //UCS8_SPRING23_REVIEW_STUBS_AND_DRIVERS_USERINPUT_H
