//
// Created by Dave R. Smith on 1/12/23.
//

#ifndef UCS8_SPRING23_REVIEW_STUBS_AND_DRIVERS_TESTS_H
#define UCS8_SPRING23_REVIEW_STUBS_AND_DRIVERS_TESTS_H
#include <iostream>
#include "Hangman.h"
#include "Opening.h"
void wordBankDriver();
void testWord();
void testBoard();
void testGame();
#endif //UCS8_SPRING23_REVIEW_STUBS_AND_DRIVERS_TESTS_H
