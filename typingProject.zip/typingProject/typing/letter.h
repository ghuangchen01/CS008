//
// Created by Guanhao Huang Chen on 3/20/23.
//

#ifndef TYPINGPROJECT_LETTER_H
#define TYPINGPROJECT_LETTER_H
#include "SFML/Graphics.hpp"

class letter: public sf::Text{

};


#endif //TYPINGPROJECT_LETTER_H
